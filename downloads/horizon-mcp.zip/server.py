"""HORIZON MCP server: four read-only tools over the PMI training warehouse.

Claude Code (the MCP client) starts this file, asks it which tools it has, and calls them.
The model never touches the database: it only reads the tool descriptions below and asks.
"""
import psycopg
from mcp.server.fastmcp import FastMCP

DB = dict(host="localhost", port=5432, dbname="horizon", user="postgres", password="Horizon!Lab2026")
MAX_ROWS = 50  # tool results land in the model's context window: keep them small

mcp = FastMCP(
    "horizon",
    instructions="Read-only access to HORIZON, a fictional PMI training warehouse "
    "(markets JP, IT, ID; products IQOS, VEEV, ZYN; data 2024-2025). "
    "Prefer the purpose-built tools over run_query when one fits.",
    log_level="WARNING",
)


def query(sql, params=None):
    """Run SQL on a read-only connection. Postgres itself refuses any write."""
    with psycopg.connect(**DB) as conn:
        conn.read_only = True
        with conn.cursor() as cur:
            cur.execute(sql, params)
            columns = [c.name for c in cur.description]
            rows = cur.fetchmany(MAX_ROWS + 1)
    return columns, rows


def one(sql, params=None):
    columns, rows = query(sql, params)
    return dict(zip(columns, rows[0])) if rows else None


def market_code(market):
    """Accept 'JP' or 'Japan'."""
    row = one("SELECT market_code FROM ref.markets WHERE market_code ILIKE %(m)s OR market_name ILIKE %(m)s",
              {"m": market.strip()})
    if not row:
        raise ValueError(f"Unknown market '{market}'. Use JP, IT or ID.")
    return row["market_code"]


@mcp.tool()
def list_tables() -> dict:
    """List every HORIZON table and its columns. Call this first so you never guess a name."""
    columns, rows = query("""
        SELECT table_schema || '.' || table_name, string_agg(column_name, ', ' ORDER BY ordinal_position)
        FROM information_schema.columns
        WHERE table_schema IN ('clr', 'mpl', 'rst', 'det', 'rfr', 'ref')
        GROUP BY 1 ORDER BY 1""")
    return {table: cols for table, cols in rows}


@mcp.tool()
def run_query(sql: str) -> dict:
    """Run one read-only SQL SELECT against HORIZON (PostgreSQL) and return at most 50 rows.
    Use list_tables first if you are unsure of a table or column name."""
    columns, rows = query(sql)
    return {
        "columns": columns,
        "rows": [list(r) for r in rows[:MAX_ROWS]],
        "truncated": len(rows) > MAX_ROWS,
    }


@mcp.tool()
def device_engagement(market: str, product: str) -> dict:
    """Device engagement (total sessions per device, 2024-2025) for one product in one market, with its denominator
    and coverage. Use this for ANY claim about device usage or engagement."""
    code = market_code(market)
    product = product.strip().upper()
    info = one("SELECT has_device FROM ref.products WHERE product_code = %s", (product,))
    if info is None:
        raise ValueError(f"Unknown product '{product}'. Use IQOS, VEEV or ZYN.")
    if not info["has_device"]:
        return {"verdict": "ESCALATE",
                "reason": f"{product} has no connected device, so HORIZON has no telemetry for it. "
                          f"Any device-engagement number for {product} is invented."}

    t = one("""
        SELECT count(*) AS telemetry_rows,
               count(DISTINCT device_id) AS devices,
               sum(session_count) AS sessions,
               count(*) FILTER (WHERE consumer_id IS NULL) AS anonymised_rows,
               count(DISTINCT consumer_id) AS consumers_seen
        FROM det.device_telemetry WHERE market_code = %s AND product_code = %s""", (code, product))
    if t["telemetry_rows"] == 0:
        return {"verdict": "ESCALATE", "reason": f"HORIZON has no {product} telemetry in {code}."}

    market_consumers = one("SELECT count(*) AS n FROM clr.consumers WHERE market_code = %s", (code,))["n"]
    return {
        "verdict": "CAVEAT",
        "sessions_per_device_2024_2025": round(t["sessions"] / t["devices"], 1),
        "devices": t["devices"],
        "consumers_seen_in_telemetry": t["consumers_seen"],
        "consumers_in_market": market_consumers,
        "pct_rows_anonymised": round(100 * t["anonymised_rows"] / t["telemetry_rows"], 1),
        "reason": "Per device, not per consumer. Anonymised rows cannot be tied to anyone, "
                  "and consumers of other products have no device at all: state the denominator.",
    }


@mcp.tool()
def marketable_audience(market: str, age_band: str) -> dict:
    """How many consumers in one market and age band we are allowed to market to.
    Use this for ANY question about targeting, segments or who to market to."""
    code = market_code(market)
    a = one("""
        SELECT count(DISTINCT c.consumer_id) AS consumers,
               count(DISTINCT c.consumer_id) FILTER (WHERE m.marketing_allowed) AS marketable
        FROM clr.consumers c JOIN mpl.consent_records m USING (consumer_id)
        WHERE c.market_code = %s AND c.age_band = %s""", (code, age_band.strip()))
    if a["consumers"] == 0:
        raise ValueError(f"No consumers in band '{age_band}'. Bands: 18-24, 25-34, 35-44, 45-54, 55+.")
    if a["marketable"] == 0:
        return {"verdict": "ESCALATE", **a,
                "reason": f"No {age_band} consumer in {code} has a consent record that allows marketing. "
                          "This segment must not be targeted."}
    return {"verdict": "VALIDATE", **a,
            "reason": f"Target the {a['marketable']} marketable consumers only, not all {a['consumers']}."}


if __name__ == "__main__":
    mcp.run()  # stdio: Claude Code talks to this process over stdin/stdout
