#!/usr/bin/env python3
"""Talk to a HORIZON MCP server the way Claude Code does, without Claude.

    python check.py                 # checks ./server.py
    python check.py path/to/server.py --defs   # also print the tool definitions the model sees

Prints PASS/FAIL for the numbers the Session 4 lab relies on. Exit code 0 means every check passed.
"""
import asyncio
import json
import os
import sys

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

HERE = os.path.dirname(os.path.abspath(__file__))


def payload(result):
    """The tool's answer as a dict (structured content when present, else the JSON text)."""
    if result.isError:
        return {"error": " ".join(c.text for c in result.content if hasattr(c, "text"))}
    if getattr(result, "structuredContent", None):
        sc = result.structuredContent
        return sc.get("result", sc) if isinstance(sc, dict) else sc
    text = " ".join(c.text for c in result.content if hasattr(c, "text"))
    try:
        return json.loads(text)
    except ValueError:
        return {"text": text}


CHECKS = [
    ("tools/list has the four tools", None, None,
     lambda names: {"list_tables", "run_query", "device_engagement", "marketable_audience"} <= set(names)),
    ("smoke: 15597 lifecycle events", "run_query", {"sql": "SELECT count(*) FROM clr.lifecycle_events"},
     lambda r: r.get("rows") == [[15597]]),
    ("ZYN in Japan barks", "device_engagement", {"market": "Japan", "product": "ZYN"},
     lambda r: r.get("verdict") == "ESCALATE"),
    ("IQOS in Japan: caveat, 20%+ anonymised", "device_engagement", {"market": "JP", "product": "IQOS"},
     lambda r: r.get("verdict") == "CAVEAT" and r.get("pct_rows_anonymised", 0) > 15),
    ("Italy 18-24: 249 consumers, 0 marketable", "marketable_audience", {"market": "IT", "age_band": "18-24"},
     lambda r: r.get("verdict") == "ESCALATE" and r.get("consumers") == 249 and r.get("marketable") == 0),
    ("Japan 18-24 passes (no over-correction)", "marketable_audience", {"market": "JP", "age_band": "18-24"},
     lambda r: r.get("verdict") == "VALIDATE" and r.get("marketable", 0) > 0),
    ("DELETE refused by the database", "run_query", {"sql": "DELETE FROM det.device_telemetry WHERE 1 = 0"},
     lambda r: "read-only" in r.get("error", "")),
]


async def main(server, show_defs):
    params = StdioServerParameters(command=sys.executable, args=[server])
    failed = 0
    async with stdio_client(params) as (read, write):
        async with ClientSession(read, write) as session:
            init = await session.initialize()
            tools = (await session.list_tools()).tools
            print(f"connected to '{init.serverInfo.name}' · {len(tools)} tools: {', '.join(t.name for t in tools)}\n")
            if show_defs:
                for t in tools:
                    print(json.dumps({"name": t.name, "description": t.description, "inputSchema": t.inputSchema}, indent=2))
                print()
            for label, tool, args, ok in CHECKS:
                if tool is None:
                    passed, shown = ok([t.name for t in tools]), ""
                else:
                    r = payload(await session.call_tool(tool, args))
                    passed, shown = ok(r), json.dumps(r, default=str)[:160]
                failed += not passed
                print(f"{'PASS' if passed else 'FAIL'}  {label}  {shown}")
    print("\nAll checks passed." if not failed else f"\n{failed} check(s) failed.")
    return failed


if __name__ == "__main__":
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    server = os.path.abspath(args[0]) if args else os.path.join(HERE, "server.py")
    sys.exit(1 if asyncio.run(main(server, "--defs" in sys.argv)) else 0)
