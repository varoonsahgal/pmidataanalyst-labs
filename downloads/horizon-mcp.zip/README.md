# HORIZON MCP server (reference copy)

A read-only MCP server over the HORIZON training warehouse. It has four tools: `list_tables`, `run_query`, `device_engagement` and `marketable_audience`. This is the same server students build in Session 4 Part 2 by prompting Claude Code. Use this copy when a student's build doesn't work.

## Set it up on a student VM (Windows)

These are instructions for Claude Code. Run them from this folder, which should be `C:\Users\<user>\horizon-mcp`:

1. Create a venv here, using `py` and not `python3`: `py -m venv .venv`
2. Install the pinned packages: `.venv\Scripts\python.exe -m pip install -r requirements.txt`
3. Write `.mcp.json` in this folder with one stdio server called `horizon`. `command` is the full path to `.venv\Scripts\python.exe`, and `args` holds the full path to `server.py`. Use forward slashes, for example:
   ```json
   {"mcpServers": {"horizon": {"command": "C:/Users/Student32/horizon-mcp/.venv/Scripts/python.exe",
                               "args": ["C:/Users/Student32/horizon-mcp/server.py"]}}}
   ```
4. Prove it works: `.venv\Scripts\python.exe check.py` should end with `All checks passed.`
5. Start a new Claude Code session with this folder as its working folder, then allow the `horizon` server when asked.

## On the instructor Mac

```bash
cd ~/pmidataanalyst/horizon-warehouse
make mcp-lab-check     # builds .venv the first time, then runs check.py against server.py
```

## What's here

| File | What it is |
|---|---|
| `server.py` | The MCP server: about 120 lines, with each tool's docstring as its description |
| `check.py` | An MCP client that connects the way Claude Code does, prints the tool definitions (`--defs`) and checks 7 numbers |
| `requirements.txt` | `mcp[cli]==1.30.0` (the last 1.x release; in 2.x FastMCP was renamed) and `psycopg[binary]==3.3.6` |
| `.claude/agents/horizon-reviewer.md` | The custom agent template from Step 7 (not in the student zip, because students create it) |

The connection uses the training superuser. The database blocks writes only because each connection is opened read-only (`conn.read_only = True`). A real deployment would use a scoped read-only role, a query log and a named owner.
